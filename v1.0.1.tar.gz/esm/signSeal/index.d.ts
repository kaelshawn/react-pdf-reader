import SignSeal from './main';
export default SignSeal;
export * from './interface';
