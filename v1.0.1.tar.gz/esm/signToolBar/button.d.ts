import type { ButtonProps } from './interface';
declare class Button {
    static create(options: ButtonProps): HTMLElement;
}
export default Button;
