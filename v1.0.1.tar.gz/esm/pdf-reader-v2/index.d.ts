import PdfReader from './main';
export default PdfReader;
