export declare function getMurmur(f?: boolean): Promise<any>;
