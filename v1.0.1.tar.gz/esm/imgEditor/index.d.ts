import ImgEditor from './main';
export default ImgEditor;
export * from './interface';
