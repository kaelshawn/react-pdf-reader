import type { IBoxSelectorParams } from './interface';
declare const _default: (options: IBoxSelectorParams) => void;
export default _default;
