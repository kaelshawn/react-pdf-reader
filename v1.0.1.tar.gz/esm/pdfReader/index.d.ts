import PdfReader from './main';
export default PdfReader;
export * from './interface';
