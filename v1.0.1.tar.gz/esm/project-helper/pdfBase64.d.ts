declare const _default: File;
export default _default;
