import Slider from './main';
export default Slider;
export * from './interface';
