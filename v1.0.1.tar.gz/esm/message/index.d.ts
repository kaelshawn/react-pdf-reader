import Message from './main';
export default Message;
export * from './interface';
