import { ApiConfig } from './utils';
export declare const init: (props: null | string | ApiConfig, cb: any) => void;
export declare function setHeader(Headers: any): void;
export declare const get: (opts: any) => Promise<unknown>;
export declare const post: (opts: any) => Promise<unknown>;
