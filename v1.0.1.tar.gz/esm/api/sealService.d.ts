export declare class _SealService {
    url: string;
    currentGongAn(): Promise<any>;
    pinVerify(params: any): Promise<any>;
    verifyAuth(params: any): Promise<any>;
    signDistinguish(params: any): Promise<any>;
}
declare const _default: _SealService;
export default _default;
