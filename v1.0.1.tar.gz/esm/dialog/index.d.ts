import Dialog from './main';
export default Dialog;
export * from './interface';
