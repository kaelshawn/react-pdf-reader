### 开发平台组件

esm 引入

````javascript
import { SignBoard } from 'isigning-open-release';
// 引入样式文件
import 'isigning-open-release/esm/styles';
````

umd 引入

````html
<link href="umd/css/main.css" rel="stylesheet">
<script src="umd/isigning.min.js"></script>
````

